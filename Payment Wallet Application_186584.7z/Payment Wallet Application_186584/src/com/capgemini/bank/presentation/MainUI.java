package com.capgemini.bank.presentation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.PaymentWalletApplicationService;
import com.capgemini.bank.service.PaymentWalletApplicationServiceImpl;


public class MainUI {

	public static void main(String[] args) throws BankException {
		String continueChoice;
		boolean continueValue = false;
		Scanner scanner = null;
		do {
			System.out.println("*** welcome to Bank Account Details***");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.WithDraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			PaymentWalletApplicationService service = new PaymentWalletApplicationServiceImpl();
			int choice = 0;
			boolean choiceflag = false;
			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceflag = true;
					String name = "";
					boolean nameFlag = false;
					switch (choice) {
					case 1: {
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Name:");
							try {
								name = scanner.nextLine();
								service.isNameValid(name);
								nameFlag = true;
							} catch (BankException e) {
								nameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!nameFlag);

						String mailId = "";
						boolean mailIdFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Email Id:");
							try {
								mailId = scanner.nextLine();
								service.isMailValid(mailId);
								mailIdFlag = true;
							} catch (BankException e) {
								mailIdFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mailIdFlag);

						String mobile = "";
						boolean mobileFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Mobile Number:");
							try {
								mobile = scanner.nextLine();
								service.isMobileValid(mobile);
								mobileFlag = true;
							} catch (InputMismatchException e) {
								mobileFlag = false;
								System.err.println("Mobile Number should be in digits");
							} catch (BankException e) {
								mobileFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobileFlag);

						String address = "";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Address:");
							try {
								address = scanner.nextLine();
								service.isAddressValid(address);
								addressFlag = true;
							} catch (BankException e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);

						Customer customer = new Customer(0, name, mailId, mobile, address, 0);
						int accountNo = 0;
						try {
							accountNo = service.createAccount(customer);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println("Account created Successfully with Account number:" + accountNo);
					}
						break;
					case 2: {
						System.out.println("Enter your account number:");
						int accountNo = scanner.nextInt();
						double balance = 0;
						try {
							balance = service.showBalance(accountNo);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println("Your balance is:" + balance);
					}
						break;

					case 3: {
						System.out.println("Enter your Account number:");
						int accountno = scanner.nextInt();
						System.out.println("Enter the amount you want to deposit:");
						double amount = scanner.nextDouble();
						List<Transaction> transaction = new ArrayList<>();
						try {
							transaction = service.deposit(accountno, amount);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}
					break;
					case 4: {
						System.out.println("Enter your Account Number:");
						int accountNo = scanner.nextInt();
						System.out.println("Enter the amount you want to withdraw:");
						double amount = scanner.nextDouble();
						List<Transaction> transaction = new ArrayList<>();
						try {
							transaction = service.withdraw(accountNo, amount);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}
						break;
					case 5: {
						System.out.println("Enter your Account Number:");
						int sourceAccountNo = scanner.nextInt();
						System.out.println("Enter the amount you want to transfer to:");
						int destinationAccountNo = scanner.nextInt();
						double amount = scanner.nextDouble();
						List<Transaction> transaction = new ArrayList<>();
						try {
							transaction = service.fundTransfer(sourceAccountNo, destinationAccountNo, amount);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}
						break;
					case 6: {
						System.out.println("Enter your Account Number:");
						int accountNo = scanner.nextInt();
						List<Transaction> transaction = new ArrayList<>();
						try {
							transaction = service.printTransactions(accountNo);
						} catch (BankException e) {
							e.printStackTrace();
						}
						System.out.println(transaction);
					}break;
					default:
						System.err.println("Input should be between 1 to 6");
						break;
					}
				} catch (InputMismatchException e) {
					choiceflag = false;
					System.err.println("Choice should be in digits");
				}
			} while (!choiceflag);
				
			do {
					scanner = new Scanner(System.in);
					System.out.println("do you want to continue again [yes/no]");
					continueChoice = scanner.nextLine();
					if (continueChoice.equalsIgnoreCase("yes")) {
						continueValue = false;
						break;
					} else if (continueChoice.equalsIgnoreCase("no")) {
						System.out.println("thank you");
						continueValue = true;
						break;
					} else {
						System.out.println("enter yes or no");
						continueValue = false;
						continue;
					}
				} while (!continueValue);
			
		} while (!continueValue);
	}
}

