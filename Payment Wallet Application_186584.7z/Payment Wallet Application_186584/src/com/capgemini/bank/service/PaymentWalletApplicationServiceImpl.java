package com.capgemini.bank.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.Customer;
import com.capgemini.bank.bean.Transaction;
import com.capgemini.bank.dao.PaymentWalletApplicationDao;
import com.capgemini.bank.dao.PaymentWalletApplicationDaoImpl;
import com.capgemini.bank.exception.BankException;

public class PaymentWalletApplicationServiceImpl implements PaymentWalletApplicationService {
	PaymentWalletApplicationDao bankDao = new PaymentWalletApplicationDaoImpl();
	@Override
	public int createAccount(Customer customer) throws BankException {
	
		return bankDao.createAccount(customer);
	}

	@Override
	public double showBalance(int accountno) throws BankException {
		return bankDao.showBalance(accountno);
	}

	@Override
	public List<Transaction> deposit(int accountno, double amount) throws BankException {
		return bankDao.deposit(accountno, amount);
	}

	@Override
	public List<Transaction> withdraw(int accountno, double amount) throws BankException {
		return bankDao.withdraw(accountno, amount);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountno, int destinationAccountNo, double amount)
			throws BankException {
		return bankDao.fundTransfer(sourceAccountno, destinationAccountNo, amount);
	}

	@Override
	public List<Transaction> printTransactions(int accountno) throws BankException {
		return bankDao.printTransactions(accountno);
	}

	@Override
	public boolean isNameValid(String name) throws BankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean isMailValid(String mail) throws BankException {
		Pattern mailPattern = Pattern.compile("[A-Za-z][@gmail.com]");
		Matcher matcher = mailPattern.matcher(mail);
		if (matcher.matches())
			throw new BankException("entered an invalid gmail Id");
		else
			return false;
	}

	@Override
	public boolean isMobileValid(String mobile) throws BankException {
		String input1 = String.valueOf(mobile);
		Pattern mobilePattern = Pattern.compile("[7,8,9]{1}[0-9]{9}");
		Matcher matcher = mobilePattern.matcher(input1);
		if (matcher.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean isAddressValid(String address) throws BankException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, address)) {
			throw new BankException("first letter should be capital and length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

}
